This folder contains Bazel configuration artifacts for a ubuntu16_04 based clang
toolchain.
